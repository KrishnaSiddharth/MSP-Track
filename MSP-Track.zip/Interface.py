import tkinter as tk

def show_entry_fields():
    print("First Name: %s\nLast Name: %s" % (e1.get(), e2.get()))
    e1.delete(0, tk.END)
    e2.delete(0, tk.END)

master = tk.Tk()
master.maxsize(1000, 1000) 
tk.Label(master, text="Length of simulation domain in centimeters: ", anchor='w', justify='left').grid(row=0)
tk.Label(master, text="Separation between the brim of the detector and the flow field inlet in centimeters: ", anchor='w', justify='left').grid(row=1)
tk.Label(master, text="Outer radius of the detector in centimeters: ", anchor='w', justify='left').grid(row=2)
tk.Label(master, text="Last Name", anchor='w').grid(row=3)
tk.Label(master, text="Last Name", anchor='w').grid(row=4)
tk.Label(master, text="Last Name", anchor='w').grid(row=5)

e1 = tk.Entry(master)
e2 = tk.Entry(master)
e3 = tk.Entry(master)
e4 = tk.Entry(master)
e5 = tk.Entry(master)
e6 = tk.Entry(master)

e1.grid(row=0, column=1)
e2.grid(row=1, column=1)
e3.grid(row=2, column=1)
e4.grid(row=3, column=1)
e5.grid(row=4, column=1)
e6.grid(row=5, column=1)

tk.Button(master, 
          text='Quit', 
          command=master.quit).grid(row=6, 
                                    column=0, 
                                    sticky=tk.W, 
                                    pady=4)
tk.Button(master, text='Show', command=show_entry_fields).grid(row=6, 
                                                               column=1, 
                                                               sticky=tk.W, 
                                                               pady=4)

master.mainloop()

tk.mainloop()