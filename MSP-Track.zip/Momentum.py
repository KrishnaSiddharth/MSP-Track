import os
import math
import random
from decimal import Decimal

t = float(input("Time step: "))
N = float(input("Number of steps: "))
c = float(input("Velocity of the gas molecule: "))
l = 0.00227
k = 0.99773
i = 1
s=0
u = 0
while i <= N:
	s = s + u*t
	#if(random.random()<=0.5):
	v = (k*u)+(l*c)
	#else:
#		v = (k*u)-(l*c)
	u = v
	i = i+1
#s = ((t*l*c)/(1-k))*(((N*(N+1))/2)-((1-pow(k,N-1))/(1-k)))
print("Total distance: ", s)
print("Velocity at final step: ", u)

key = input("Enter any key to close program:")
