from PIL import Image
from decimal import Decimal

import sympy as sym
from sympy import *

import os
import math
import random
import shutil

__location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))
legend = Image.open(os.path.join(__location__, 'Legends\\'+'legend'+'P'+'.JPG'),'r')
pix = legend.load()
i = 0
while i < legend.width :
	print(pix[i,0])
	i = i + 1