import os

n = float(input("Enter Number Density:"))
print(abs(n))