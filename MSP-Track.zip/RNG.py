import random

rnd = []
i = 0
while i < 5:
	j = 0
	rnd.append([])
	random.seed(i)
	while j < 5:
		rnd[i].append(random.random())
		j = j+1
	i = i+1
print(rnd)
set = 0
while set < 5:     # deleting the first element of the list of random number in the each set since it already has been assigned
	rnd[set].pop(0) 
	set = set + 1

print(rnd)

#j = 1
#while  j < 5:
#	i = 1
#	while i< 10:
#		print(random.random())
#		print(random.random())
#		print(random.random())
#		print('\n')
#		i = i+1
#	j = j+1
#random.seed(1)
#for i in range(100):
#	print(random.gauss(5,0.5))
#print('\n')
#random.seed(2)
#for i in range(1000):
#	print(random.gauss(5,1.5))

