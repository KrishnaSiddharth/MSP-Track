import sympy as sym
from sympy import *
x = sym.symbols('x')
cons = sym.symbols('cons')
I = sym.integrate(((x**2)*exp(-((x-cons)**2))) - exp(-((x+cons)**2)),(x,0,oo))
print(I)
a = 0.1
print(float(I.subs(cons,a)))